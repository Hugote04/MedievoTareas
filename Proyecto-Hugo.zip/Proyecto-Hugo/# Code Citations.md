# Code Citations

## License: unknown
https://github.com/fkshom/template_engine_Libvue_element_plus/tree/b132c81d27e6f65c6c3fa29e802f7674164f54fa/template_engine_vue.orig2/src/App.vue

```
template>
  <v-app>
    <v-app-bar app color="primary" dark>
      <v-app-bar-nav-icon @click="drawer = !drawer"></v-app-bar-nav-icon>
      <v
```


## License: unknown
https://github.com/toma68/Vilains-Vilains/tree/627d8fe14c68e54f744b7512ed08db859c6edb58/src/App.vue

```
>
  <v-app>
    <v-app-bar app color="primary" dark>
      <v-app-bar-nav-icon @click="drawer = !drawer"></v-app-bar-nav-icon>
      <v-
```


## License: unknown
https://github.com/open-roboclub/roboclub-vue/tree/04a90c1937ac46b0fa8f4f9522898e93226624b4/pages/profile.vue

```
</v-list-item-avatar>
          <v-list-item-content>
            <v-list-item-title>{{ user.displayName }}</v-list-item-title>
          </v-list-item-content>
```


## License: Apache_2_0
https://github.com/gbrunois/plan-your-meals/tree/480814949ed415a64f0fe701fe215a8c7505b6f3/packages/front/src/components/AppNavigation.vue

```
<v-list-item-content>
            <v-list-item-title>{{ user.displayName }}</v-list-item-title>
          </v-list-item-content>
        </v-list-item>
        <v
```


## License: unknown
https://github.com/aquispesegales/inventario-ventas/tree/831773d19a6c380021cbc169c642a877dd1d7451/src/shared/AppMenu.vue

```
item-icon>
            <v-icon>mdi-home</v-icon>
          </v-list-item-icon>
          <v-list-item-title>Inicio</v-list-item-title>
        </v-list-item
```

